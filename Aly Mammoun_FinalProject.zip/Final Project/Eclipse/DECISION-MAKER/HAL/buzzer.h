/*
 * buzzer.h
 *
 *  Created on: Oct 21, 2021
 *      Author: user
 */

#ifndef HAL_BUZZER_H_
#define HAL_BUZZER_H_

#include "../UTILITIES/std_types.h"

#define BUZZER_PORT 		PORTA_ID
#define BUZZER_PIN			PIN0_ID

void BuzzerInit(void);
void BuzzerOn(void);
void BuzzerOff(void);



#endif /* HAL_BUZZER_H_ */

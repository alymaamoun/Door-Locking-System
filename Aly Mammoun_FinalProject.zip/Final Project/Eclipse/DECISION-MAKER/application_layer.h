/*-----------------------------------------------------------------------------------------
 * File Name:		application_layer.h
 *
 * Author: 			Aly Maamoun
 *
 * Date: 			26/10/2021
 *
 * Description: 	header file for Decision maker program
 *
 -----------------------------------------------------------------------------------------*/

#ifndef APPLICATION_LAYER_H_
#define APPLICATION_LAYER_H_

#include "UTILITIES/std_types.h"

typedef enum{
	error, PASS2 , PASS, NEW_SYSTEM , MAIN_MENU, INCORRECT_PASSWORD,UNLOCKING,UNLOCKED,LOCKING,LOCKED
}COMMANDS;

#define DOOR_TIME 15
#define HOLD_TIME 3
#define ALARM_TIME 60
#define PASSWORD_SIZE 5
#define EEPROM_TIME 100
#define CHANCES 3


void flagCheck	(void);
uint8 PassLoad	(void);
uint8 PassCompare(void);
uint8 PassWrite	(void);
void newSystem	(void);
uint8 newPassword(void);
void mainMenu	(void);
void PassRecieve(void);
void Timer		(void);
void system		(void);
void Alert		(void);
void DoorControl(void);
void timer2();
void MainPassCheck();
void performOption(COMMANDS option);

#endif /* APPLICATION_LAYER_H_ */

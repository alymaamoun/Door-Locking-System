/*-----------------------------------------------------------------------------------------
 * File Name:		application_layer.c
 *
 * Author: 			Aly Maamoun
 *
 * Date: 			23/10/2021
 *
 * Description: 	Source file for Decision maker program
 *
 -----------------------------------------------------------------------------------------*/



/*-------------------------------------------------------------------------------------------
 * ------------------------------------------------------------------------------------------
 *										INCLUDES
 *-------------------------------------------------------------------------------------------
 ------------------------------------------------------------------------------------------*/




#include "application_layer.h"
#include "MCAL/uart.h"
#include "MCAL/timer.h"
#include "MCAL/gpio.h"
#include "MCAL/twi.h"
#include "HAL/buzzer.h"
#include "HAL/external_eeprom.h"
#include "HAL/motor.h"
#include "UTILITIES/common_macros.h"
#include "util/delay.h"
#include <avr/io.h>


/*-------------------------------------------------------------------------------------------
 * ------------------------------------------------------------------------------------------
 *										Global variables
 *-------------------------------------------------------------------------------------------
 ------------------------------------------------------------------------------------------*/


uint8 password1[PASSWORD_SIZE];				//receive password from USER-INTERFACE
uint8 PassEEPROM[PASSWORD_SIZE];			//communicate with the EEPROM
uint8 flag;						//check if old system or new system
uint32 time=0;					//hold seconds
uint8 data;						//hold data needed to be sent
uint8 chances=0;				//hold number of chances of entering correct password


const uint16 FLAG=100;			//hold the address to be written at on EEPROM for flag
const uint16 PASS_0=0;			//hold the address to be written at on EEPROM for pass[0]


/*-------------------------------------------------------------------------------------------
 * ------------------------------------------------------------------------------------------
 *										Function definition
 *-------------------------------------------------------------------------------------------
 ------------------------------------------------------------------------------------------*/

void flagCheck(void){ 			//checking flag
	EEPROM_readByte(FLAG, &flag);
	_delay_ms(EEPROM_TIME);
}
void flagWrite(void){			//writing statues of flag on EEPROM
	EEPROM_writeByte(FLAG, flag);
	_delay_ms(EEPROM_TIME);
}
uint8 PassLoad(void){			//getting password from EEPROM
	for(int i=0;i<PASSWORD_SIZE;i++){
		uint32 address=PASS_0+i;
		EEPROM_readByte(address, PassEEPROM+i);
		_delay_ms(EEPROM_TIME);
	}
	return 1;
}
uint8 PassWrite(void){			//writing password on EEPROM
	for(int i=0;i<PASSWORD_SIZE;i++){
		uint32 address=PASS_0+i;
		EEPROM_writeByte(address, password1[i]);
		_delay_ms(EEPROM_TIME);
	}


	return 1;
}
uint8 newPassword(void){
	int i;
	for(i=0;i<PASSWORD_SIZE;i++){
		password1[i]=UART_recieveByte();	//receiving password from user interface

	}

	while(!PassWrite());					//busy loop to finish




	for(i=0;i<PASSWORD_SIZE;i++){
		password1[i]=UART_recieveByte();	//receiving ack password

	}
	while(!PassLoad());						//busy loop


	return PassCompare();
}
uint8 PassCompare(void){					//returns 1 if pass matches otherwise returns 0
	int i;
	for(i=0;i<PASSWORD_SIZE;i++){
		if(PassEEPROM[i]!=password1[i]){	//comparing the password entered to the password loaded from EEPROM
			return 0;
		}
	}
	return 1;
}
void Timer(void){
	time++;
}
void newSystem(void){
	UART_sendByte(NEW_SYSTEM);				//informing the UI to perform the new-system function
	if(!newPassword()){
		newSystem();						//while new password not matching
	}
	flag=1;
	flagWrite();							//writing in EEPROM that flag is 1 (old system)
	mainMenu();								//going to main menu
}
void PassRecieve(void){


	for(int i=0;i<PASSWORD_SIZE;i++){

		password1[i]=UART_recieveByte();	//receiving password

	}
}
void Alert(void){

	time=0;									//start counting with zero reference

	BuzzerOn();								//turning on alarm
	UART_sendByte(error);					//sending to UI to perform error function

	while((time)<=ALARM_TIME){						//60 seconds
	}
	BuzzerOff();							//turning off alarm
	mainMenu();								//return to main menu
}

void performOption(COMMANDS option){
	if (option==UNLOCKING){
		DoorControl();
	}
	else if(option==NEW_SYSTEM){
		newSystem();
	}
}
void MainPassCheck(){
	uint8 validaty=0;
	UART_sendByte(PASS);				//send command to enter password
	while(validaty==0){
		PassRecieve();					//receiving password
		validaty=PassCompare();			//comparing

		if(validaty==1){
			chances=0;
			performOption(data);		//performing the chosen option if password matches
		}
		else if(chances==(CHANCES-1)){
			chances=0;					//reset chances counter;
			Alert();					//turning on alarm


		}

		else if(validaty==0){
			chances++;					//incrementing incorrect times
			UART_sendByte(INCORRECT_PASSWORD);

		}


	}
}


void mainMenu(void){

	UART_sendByte(MAIN_MENU);				//sending to UI to perform main menu functions
	data=UART_recieveByte();				//receiving option choose
	MainPassCheck();						//checking the incoming password

}
void DoorControl(void){
	time=0;									//reseting timer counter
	UART_sendByte(UNLOCKING);				//printing unlocking
	DcMotor_Rotate(CW, 100);				//opening door
	while((time)<DOOR_TIME){						//15 seconds
	}
	time=0;
	UART_sendByte(UNLOCKED);
	DcMotor_Rotate(stop, 0);
	while((time)<HOLD_TIME){
	}
	time=0;

	DcMotor_Rotate(A_CW, 100);
	UART_sendByte(LOCKING);
	while((time)<DOOR_TIME){
	}
	time=0;

	UART_sendByte(LOCKED);
	DcMotor_Rotate(stop, 0);
	while((time)<HOLD_TIME){
	}
	time=0;
	mainMenu();								//going to main menu
}
void system		(void){
	flagCheck();							//checking if system is old or new
	if(flag==1){							//case old system
		while(!PassLoad());					//load pass from eeprom
		mainMenu();							//going to main menu
	}
	else{									//case new system

		newSystem();

	}
}


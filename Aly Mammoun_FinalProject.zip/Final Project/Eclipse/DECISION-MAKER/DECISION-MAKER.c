#define F_CPU 8000000UL
#include <avr/io.h>
#include "MCAL/gpio.h"
#include "MCAL/pwm.h"
#include "MCAL/timer.h"
#include "MCAL/uart.h"
#include "MCAL/twi.h"
#include "UTILITIES/common_macros.h"
#include "UTILITIES/std_types.h"
#include "HAL/motor.h"
#include "HAL/buzzer.h"
#include "HAL/external_eeprom.h"
#include "util/delay.h"
#include "application_layer.h"

#define READY 0x0F








uint8 data;



void Inits(void);






int main(void){
	Inits();
	data=READY;
	UART_sendByte(data);
	//for(int i=0;i<5;i++){
	//EEPROM_writeByte(0x00+i, 0);}
	while(1){
		system();
	}
}
void Inits(void){
	TIMER_CONFIG config;
	config.Channel_A=LOGIC_HIGH;
	config.Channel_B=LOGIC_LOW;
	config.compare=31250;
	config.compare_mode=TIMER_NORMAL;
	config.inital=0;
	config.mode=COMPARE;
	config.prescalar=TIMER_FCPU_256;
	config.timer=TIMER1;


	BuzzerInit();
	DcMotor_Init();


	TWI_Configurations TWI_config;
	TWI_config.bitRate=0x02;
	TWI_config.slaveAddress=0x2;

	TWI_init(&TWI_config);

	Timer_init(&config);

	UART_config uart;
	uart.BaudRate=9600;
	uart.bit_data=8;
	uart.parity=UART_disabled;
	uart.stopBits=UART_1bit;
	UART_init(&uart);


	GPIO_setupPinDirection(PORTA_ID, PIN0_ID, PIN_OUTPUT);
	GPIO_writePin(PORTA_ID, PIN4_ID, LOGIC_LOW);
	Timer_callBackFunction(Timer, TIMER1);
	SET_BIT(SREG,7);
}


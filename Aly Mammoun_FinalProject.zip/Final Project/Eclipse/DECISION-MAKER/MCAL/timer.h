#ifndef INTERNAL_PERIPHERALS_TIMER_H_
#define INTERNAL_PERIPHERALS_TIMER_H_

#include "../UTILITIES/std_types.h"


#define REQUIRED_TIME 	10
#define MAX_COUNT 		255
#define REFACTOR		1000
#define LOOP 			33

typedef enum{
	TIMER0,TIMER1,TIMER2
}TIMER_ID;

typedef enum{
	OVF,x,COMPARE
}TIMER_MODE;

typedef enum{
	TIMER_NO_CLK,TIMER_FCPU,TIMER_FCPU_8,TIMER_FCPU_64,TIMER_FCPU_256,TIMER_FCPU_1024
}TIMER_PRESCALAR;

typedef enum{
	TIMER_NORMAL,TIMER_TOGGLE,TIMER_CLEAR,TIMER_SET
}TIMER_COMPARE_MODE;

typedef enum{
	TIMER2_NO_CLK,TIMER2_FCPU,TIMER2_FCPU_8,TIMER2_FCPU_32,TIMER2_FCPU_64,TIMER2_FCPU_128,TIMER2_FCPU_256,TIMER2_FCPU_1024
}TIMER2_PRESCALAR;

typedef struct{
	TIMER_ID timer;
	TIMER_PRESCALAR prescalar;
	TIMER2_PRESCALAR prescalar_2;
	uint8 Channel_A;
	uint8 Channel_B;
	TIMER_MODE mode;
	TIMER_COMPARE_MODE compare_mode;
	uint16 inital;
	uint16 compare;
}TIMER_CONFIG;

void Timer_init(const TIMER_CONFIG * Config);
void Timer_callBackFunction(void(*c_ptr)(void),TIMER_ID channel);
void Timer_deinit(TIMER_ID channel);
#endif /* INTERNAL_PERIPHERALS_TIMER_H_ */

#include "timer.h"

#include <avr/io.h>
#include "../UTILITIES/common_macros.h"
#include "gpio.h"
#include <avr/interrupt.h>


static volatile void(*T0_callBack)(void)=NULL_PTR;
static volatile void(*T1_callBack)(void)=NULL_PTR;
static volatile void(*T2_callBack)(void)=NULL_PTR;


ISR(TIMER0_COMP_vect){
	if(T0_callBack!=NULL_PTR){


			T0_callBack();


	}
}

ISR(TIMER0_OVF_vect){
	if(T0_callBack!=NULL_PTR){


			T0_callBack();


	}
}


ISR(TIMER1_COMPA_vect){
	if(T1_callBack!=NULL_PTR){
		T1_callBack();
	}
}

ISR(TIMER1_COMPB_vect){
	if(T1_callBack!=NULL_PTR){
		T1_callBack();
	}
}

ISR(TIMER1_OVF_vect){
	if(T1_callBack!=NULL_PTR){
		T1_callBack();
	}
}


ISR(TIMER2_COMP_vect){
	if(T2_callBack!=NULL_PTR){


			T2_callBack();

		}

}

ISR(TIMER2_OVF_vect){
	if(T2_callBack!=NULL_PTR){


			T2_callBack();


	}
}


void Timer_init(const TIMER_CONFIG * Config){

	if((Config->timer)==TIMER0){
		SET_BIT(TCCR0,FOC0);
		TCCR0=(TCCR0&0xCF)|((Config->compare_mode)<<COM00);
		TCCR0=(TCCR0&0xF8)|(Config->prescalar);
		TCNT0=Config->inital;
		OCR0=Config->compare;
		if((Config->mode)==OVF){
			CLEAR_BIT(TCCR0,WGM00);
			CLEAR_BIT(TCCR0,WGM01);
			SET_BIT(TIMSK,TOIE0);
		}
		else if((Config->mode)==COMPARE){
			CLEAR_BIT(TCCR0,WGM00);
			SET_BIT(TCCR0,WGM01);
			SET_BIT(TIMSK,OCIE0);
		}
	}




	else if((Config->timer)==TIMER1){
		SET_BIT(TCCR1A,FOC1A);
		SET_BIT(TCCR1A,FOC1B);
		TCCR1B=(TCCR1B&0xF8)|(Config->prescalar);
		TCNT1=Config->inital;

		if((Config->mode)==OVF){
			CLEAR_BIT(TCCR1A,WGM10);
			CLEAR_BIT(TCCR1A,WGM11);
			CLEAR_BIT(TCCR1B,WGM12);
			CLEAR_BIT(TCCR1A,WGM13);
			SET_BIT(TIMSK,TOIE1);
		}
		else if((Config->mode)==COMPARE){
			CLEAR_BIT(TCCR1A,WGM10);
			CLEAR_BIT(TCCR1A,WGM11);
			SET_BIT(TCCR1B,WGM12);
			CLEAR_BIT(TCCR1A,WGM13);
			if((Config->Channel_A)==LOGIC_HIGH){
				TCCR1A=(TCCR1A&0x3F)|((Config->compare_mode)<<COM1A0);
				OCR1A=Config->compare;
				SET_BIT(TIMSK,OCIE1A);
			}
			if((Config->Channel_B)==LOGIC_HIGH){
				TCCR1A=(TCCR1A&0xBF)|((Config->compare_mode)<<COM1B0);
				OCR1B=Config->compare;
				SET_BIT(TIMSK,OCIE1B);
			}
		}


	}





	else if((Config->timer)==TIMER2){
		SET_BIT(TCCR2,FOC2);
		TCCR2=(TCCR2&0xBF)|(((Config->mode)&0x01)<<WGM20);
		TCCR2=(TCCR2&0xF7)|(((Config->mode)&0x02)<<WGM21);
		TCCR2=(TCCR2&0xCF)|((Config->compare_mode)<<COM20);
		TCCR2=(TCCR2&0xF8)|((Config->prescalar_2));
		TCNT2=Config->inital;
		OCR2=Config->compare;
		if((Config->mode)==OVF){
			SET_BIT(TIMSK,TOIE2);
		}
		else if((Config->mode)==COMPARE){
			SET_BIT(TIMSK,OCIE2);
		}

	}
}
void Timer_callBackFunction(void(*c_ptr)(void),TIMER_ID channel){
	if(channel==TIMER0)
		T0_callBack=c_ptr;
	else if(channel==TIMER1){
		T1_callBack=c_ptr;
	}
	else if(channel==TIMER2){
		T2_callBack=c_ptr;
	}
}
void Timer_deinit(TIMER_ID channel){
	if(channel==TIMER0)
	{
		TCCR0=0;
		TCNT0=0;
		OCR0=0;
	}
	else if(channel==TIMER1){
		TCCR1A=0;
		TCCR1B=0;
		TCNT1=0;
		OCR1A=0;
		OCR1B=0;
	}
	else if(channel==TIMER2){
		TCCR2=0;
		TCNT2=0;
		OCR2=0;
	}
}

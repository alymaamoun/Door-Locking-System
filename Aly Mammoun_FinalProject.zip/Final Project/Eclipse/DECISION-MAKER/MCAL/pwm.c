#include "gpio.h"
#include "../UTILITIES/common_macros.h"
#include <avr/io.h>
#include "pwm.h"





void TIMER0_pwm_init(PRESCALAR prescalar){
	TCNT0=0;
	OCR0=0;
	TCCR0=0;
	TCCR0=prescalar;
	SET_BIT(TCCR0,WGM00);
	SET_BIT(TCCR0,WGM01);
	TCCR0=(TCCR0&0xcf)|(1<<COM01);
	GPIO_setupPinDirection(PORTB_ID, PIN3_ID, PIN_OUTPUT);

}
void TIMER0_pwm(uint8 duty_cycle){
	OCR0=duty_cycle;
}

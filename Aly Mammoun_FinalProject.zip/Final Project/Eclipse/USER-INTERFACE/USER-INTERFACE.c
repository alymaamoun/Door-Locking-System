/*-----------------------------------------------------------------------------------------
 * File Name:		application_layer.c
 *
 * Author: 			Aly Maamoun
 *
 * Date: 			26/10/2021
 *
 * Description: 	Source file for UI program
 *
 -----------------------------------------------------------------------------------------*/


/*-------------------------------------------------------------------------------------------
 * ------------------------------------------------------------------------------------------
 *										INCLUDES
 *-------------------------------------------------------------------------------------------
 ------------------------------------------------------------------------------------------*/


#define F_CPU 8000000UL
#include "HAL/keypad.h"
#include "HAL/lcd.h"
#include "UTILITIES/common_macros.h"
#include "MCAL/timer.h"
#include "MCAL/gpio.h"
#include "MCAL/uart.h"

#define READY 0x0F


typedef enum{
	error, PASS2 , PASS, NEW_SYSTEM , MAIN_MENU, INCORRECT_PASSWORD,UNLOCKING,UNLOCKED,LOCKING,LOCKED
}COMMANDS;

uint8 system =0;				//old or new

/*-------------------------------------------------------------------------------------------
 * ------------------------------------------------------------------------------------------
 *								functions prototype
 *-------------------------------------------------------------------------------------------
 ------------------------------------------------------------------------------------------*/

void Enter_pass(void);					//printing enter password
void NewPass(void);						//printing enter new password
void Incorrect(void);					//printing incorrect password
void ReEnter(void);						//printing Re enter password
void MainMenu(void);					//printing the main menu open door or change password
void pass_reciver(void);				//receiving password from user in array
void System(COMMANDS command);			//function takes command type to choose what to do , command comes from DECISION MAKER
void NewSystem(void);					//holding the functionality that performs if new system or changing password
void Unlocking();						//printing unlocking
void Unlocked();						//printing unlocked
void Locking();							//printing locking
void Locked();							//printing locked
void Old_pass_Passer();					//passing the password to DECISION MAKER through UART
void Init();							//contains the initialization of modules used
void Error();							//printing errors

/*-------------------------------------------------------------------------------------------
 * ------------------------------------------------------------------------------------------
 *									Global variable
 *-------------------------------------------------------------------------------------------
 ------------------------------------------------------------------------------------------*/

uint8 password[5];						//array containing
uint8 data;
uint8 testFactor=0;						//48 if testing with virtual terminal , 0 if real system

/*-------------------------------------------------------------------------------------------
 * ------------------------------------------------------------------------------------------
 *									Main function
 *-------------------------------------------------------------------------------------------
 ------------------------------------------------------------------------------------------*/

int main(void){
	Init();								//calling the initializing
	if(UART_recieveByte()==READY){		//waiting to sync with the other board;
		while(1){
			data=UART_recieveByte();	//holding the data sent from


			System(data-testFactor);	//sending the needed command to the tasks handler


		}
	}
}

/*-------------------------------------------------------------------------------------------
 * ------------------------------------------------------------------------------------------
 *									Functions definitions
 *-------------------------------------------------------------------------------------------
 ------------------------------------------------------------------------------------------*/

void Error(){
	LCD_displayStringRowColumn(0, 0, "ERROR            ");
	LCD_displayStringRowColumn(1, 0, "                 ");
}

void Init(){
	UART_config uart;
	uart.BaudRate=9600;
	uart.bit_data=8;
	uart.parity=UART_disabled;
	uart.stopBits=UART_1bit;
	UART_init(&uart);
	LCD_init();

}



void Enter_pass(void){
	LCD_clearScreen();
	LCD_displayStringRowColumn(0, 0, "enter Password");
}
void Incorrect(void){
	LCD_clearScreen();
	LCD_displayStringRowColumn(0, 0, "Incorrect pass");
}
void ReEnter(void){
	LCD_clearScreen();
	LCD_displayStringRowColumn(0, 0, "enter it again");
}
void MainMenu(void){
	LCD_clearScreen();
	LCD_displayStringRowColumn(0, 0, "+:Open door");
	LCD_displayStringRowColumn(1, 0, "-:change pass");
}
void pass_reciver(void){

	LCD_moveCursor(1, 0);
	LCD_displayString("               ");
	LCD_moveCursor(1, 0);
	int i=0;
	while(i<5){
		if(KEYPAD_getPressedKey()<10){					//preventing + and - to be the first character of the password
			password[i]=KEYPAD_getPressedKey();			//adding the key to the array of password if it matches conditions "0 to 9"
			LCD_displayCharacter('*');					//printing * after each successful number pressed

			i++;
			while((GPIO_readPin(PORTA_ID, PIN0_ID)==0)||(GPIO_readPin(PORTA_ID, PIN1_ID)==0)||(GPIO_readPin(PORTA_ID, PIN2_ID)==0)||(GPIO_readPin(PORTA_ID, PIN3_ID)==0));	//waiting till the key is released


		}
	}
}
void Old_pass_Passer(){
	pass_reciver();										//receiving password
	for(int i=0;i<5;i++){
		UART_sendByte(password[i]+testFactor);			//sending number each time through UART
	}
}
void NewSystem(void){
	NewPass();											//printing enter new pass
	pass_reciver();										//receiving password
	for(int i=0;i<5;i++){
		UART_sendByte(password[i]+testFactor);			//sending number each time through UART
	}

	ReEnter();											//printing Re enter password
	pass_reciver();										//receiving password
	for(int i=0;i<5;i++){
		UART_sendByte(password[i]+testFactor);			//sending number each time through UART
	}

}
void Unlocking(){

	LCD_displayStringRowColumn(0, 0, "UNLOCKING        ");
	LCD_displayStringRowColumn(1, 0, "                  ");


}
void Unlocked(){
	LCD_displayStringRowColumn(0, 0, "UNLOCKED         ");

}
void Locking(){

	LCD_displayStringRowColumn(0, 0, "LOCKING         ");

}
void Locked(){

	LCD_displayStringRowColumn(0, 0, "LOCKED          ");


}
void NewPass(void){
	LCD_displayStringRowColumn(0, 0, "Enter new Pass          ");
}
void System(volatile COMMANDS command){


	if(command==MAIN_MENU){
		system=1;									//system is old
		MainMenu();									//display main menu
		data=KEYPAD_getPressedKey();				//storing option in data
		while(!((data=='+')||(data=='-'))){			// if data not equal + or - wait for valid input
			data=KEYPAD_getPressedKey();
		}
		if(data=='+'){
			UART_sendByte(UNLOCKING);
		}
		else if(data=='-'){
			UART_sendByte(NEW_SYSTEM);
		}

	}

	else if(command==NEW_SYSTEM){
		system=0;									//system is new
		NewSystem();								//new system function (entering password twice)
	}
	else if(command==INCORRECT_PASSWORD){
		Incorrect();
		Old_pass_Passer();
	}
	else if(command==PASS){
		Enter_pass();

		Old_pass_Passer();
	}
	else if(command==UNLOCKING)
		Unlocking();
	else if(command==UNLOCKED)
		Unlocked();
	else if(command==LOCKING)
		Locking();
	else if(command==LOCKED)
		Locked();
	else if(command==error){
		Error();

	}

}
